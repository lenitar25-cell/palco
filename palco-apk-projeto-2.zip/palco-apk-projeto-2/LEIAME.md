# Palco: gerar o APK de teste

## Opção 1: sem instalar nada (GitHub)
1. Crie uma conta gratuita em github.com e um repositório novo.
2. Envie todo o conteúdo desta pasta para o repositório (botão "Add file > Upload files"). Inclua a pasta .github.
3. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow**.
4. Em uns 5 minutos, abra a execução concluída e baixe **palco-apk** (dentro vem o app-debug.apk).
5. Passe o arquivo para o celular e instale (permita "instalar apps desconhecidos").

## Opção 2: no seu computador
Precisa de Node 20, Java 17 e Android Studio.
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
O APK fica em android/app/build/outputs/apk/debug/app-debug.apk

## Importante
- Este APK é o mesmo protótipo da página, empacotado. É um APK de teste (debug), não serve para publicar na Play Store.
- Transmitir a tela do celular não funciona dentro desse empacotamento. Isso exige um plugin nativo (MediaProjection do Android), que fica para a próxima etapa.
